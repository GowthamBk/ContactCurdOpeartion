package com.example.myapplication.db.entity;

public class ContactPhone {

    private String number;

    public ContactPhone(String number) {
        this.number = number;
    }

    public String getNumber() {
        return number;
    }

}
