package com.example.myapplication.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.ContactActivity;
import com.example.myapplication.R;
import com.example.myapplication.db.entity.Contact;

import java.util.ArrayList;

public class ContactsAdapter extends RecyclerView.Adapter<ContactsAdapter.ViewHolder> {

    private ContactActivity contactActivity;
    private ArrayList<Contact> listContacts;

    public ContactsAdapter(ContactActivity contactActivity, ArrayList<Contact> listContacts) {
        this.contactActivity = contactActivity;
        this.listContacts = listContacts;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView name;
        private TextView number;
        private ImageView imgContact;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            number = itemView.findViewById(R.id.number);
            imgContact = itemView.findViewById(R.id.img_contact);
        }
    }

    @NonNull
    @Override
    public ContactsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.contact_list_item, viewGroup, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactsAdapter.ViewHolder viewHolder, final int i) {
        final Contact contact = listContacts.get(i);

        viewHolder.name.setText(contact.getName());
        viewHolder.number.setText(contact.getNumbers().get(0).getNumber());
        if (contact.getUri() != null) {
            String img = contact.getUri().toString();
            if(!img.equals("")) {
                viewHolder.imgContact.setImageURI(contact.getUri());
            }else {
                viewHolder.imgContact.setImageResource(R.drawable.ic_contact);
            }
        } else {
            viewHolder.imgContact.setImageResource(R.drawable.ic_contact);
        }
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                contactActivity.addAndEditContacts(true, contact, i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listContacts.size();
    }
}
