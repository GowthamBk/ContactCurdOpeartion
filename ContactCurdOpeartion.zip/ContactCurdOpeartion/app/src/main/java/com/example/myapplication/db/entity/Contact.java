package com.example.myapplication.db.entity;

import android.net.Uri;

import java.util.ArrayList;

public class Contact {

    public static final String TABLE_NAME = "contacts";

    public static final String COLUMN_ID = "contact_id";
    public static final String COLUMN_NAME = "contact_name";
    public static final String COLUMN_NUMBER = "contact_number";
    public static final String COLUMN_IMAGE = "contact_image";

    private String name;
    private ArrayList<ContactPhone> numbers;
    private String id;
    private Uri uri;

    public Contact() {
    }

    public Contact(String id, String name, ArrayList<ContactPhone> numbers, Uri uri) {

        this.name = name;
        this.numbers = numbers;
        this.id = id;
        this.uri = uri;
    }

    public String getName() {
        return name;
    }

    public Uri getUri() {
        return uri;
    }

    public void setUri(Uri uri) {
        this.uri = uri;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ArrayList<ContactPhone> getNumbers() {
        return numbers;
    }

    public void setNumbers(ArrayList<ContactPhone> numbers) {
        this.numbers = numbers;
    }

    // Create table SQL query
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_NAME + " TEXT,"
                    + COLUMN_NUMBER + " TEXT,"
                    + COLUMN_IMAGE + " BLOB"
                    + ")";
}

