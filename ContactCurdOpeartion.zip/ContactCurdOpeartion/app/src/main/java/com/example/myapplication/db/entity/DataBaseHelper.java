package com.example.myapplication.db.entity;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;

import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private String id;
    private Context ctx;
    private static final String DATABASE_NAME = "contact_db";

    private ArrayList<Contact> alContacts = new ArrayList<>();
    private ArrayList<ContactPhone> contactPhoneArrayList = new ArrayList<>();


    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        ctx = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Contact.CREATE_TABLE);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + Contact.TABLE_NAME);


        onCreate(db);
    }

    public boolean CheckIsDataAlreadyInDBorNot() {
        SQLiteDatabase db = this.getReadableDatabase();
        //String query = "Select * from " + Contact.TABLE_NAME;
        Cursor cursor = db.query(Contact.TABLE_NAME, null, null, null, null, null, null);
        if (cursor.getCount() <= 0) {
            cursor.close();
            return false;
        } else {
            cursor.close();
            return true;
        }
    }

    public ArrayList<Contact> fetchAllRecordFromDataBase() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor contactCursor = db.rawQuery("SELECT * FROM " + Contact.TABLE_NAME, null);
        if (contactCursor.moveToFirst()) {
            //looping through all the records
            do {
                String id = String.valueOf(contactCursor.getString(0));
                String name = String.valueOf(contactCursor.getString(1));
                String number = String.valueOf(contactCursor.getString(2));
                String image = String.valueOf(contactCursor.getString(3));
                contactPhoneArrayList.add(new ContactPhone(number));
                Uri u = Uri.parse(image);
                alContacts.add(new Contact(id, name, contactPhoneArrayList, u));

            } while (contactCursor.moveToNext());
        }
        contactCursor.close();
        return alContacts;
    }

    public long insertContact(String name, String number, String image) {


        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(Contact.COLUMN_NAME, name);
        values.put(Contact.COLUMN_NUMBER, number);
        values.put(Contact.COLUMN_IMAGE, image);

        long id = db.insert(Contact.TABLE_NAME, null, values);

        db.close();

        return id;
    }

    public ArrayList<Contact> fetchRecordFromContact() {
        ArrayList<Contact> alContacts = new ArrayList<>();
        //String id;
        ContentResolver cr = ctx.getContentResolver();
        Cursor cursor = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                //String contactImage = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.PHOTO_URI));

                if (Integer.parseInt(cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                    Cursor pCur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        String contactNumber = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        ArrayList<ContactPhone> contactPhones = new ArrayList<>();
                        ContactPhone contactPhone = new ContactPhone(contactNumber);
                        contactPhones.add(contactPhone);
                        Uri u = getPhotoUri();
                        insertContact(name, contactNumber, u == null ? "" : String.valueOf(u));
                        Contact contact;
                        if (u != null) {
                            // mPhotoView.setImageURI(u);
                            contact = new Contact(id, name, contactPhones, u);

                            Log.i("photo", "exist");
                        } else {
                            contact = new Contact(id, name, contactPhones, u);
                            //mPhotoView.setImageResource(R.drawable.ic_contact_picture_2);
                            Log.i("photo", "not exist");
                        }
                        alContacts.add(contact);
                        break;
                    }
                    pCur.close();
                }

            } while (cursor.moveToNext());
        }

        return alContacts;
    }

    public Contact getContact(long id) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(Contact.TABLE_NAME,
                new String[]{Contact.COLUMN_ID, Contact.COLUMN_NAME, Contact.COLUMN_NUMBER},
                Contact.COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        Contact contact = new Contact();
        contact.setId(cursor.getString(cursor.getColumnIndex(Contact.COLUMN_ID)));
        contact.setName(cursor.getString(cursor.getColumnIndex(Contact.COLUMN_NAME)));
        ArrayList<ContactPhone> contactPhoneArrayList = new ArrayList<>();
        ContactPhone contactPhone = new ContactPhone(cursor.getString(cursor.getColumnIndex(Contact.COLUMN_NUMBER)));
        contactPhoneArrayList.add(contactPhone);
        contact.setNumbers(contactPhoneArrayList);

        cursor.close();

        return contact;
    }

    public int updateContact(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Contact.COLUMN_NAME, contact.getName());
        values.put(Contact.COLUMN_NUMBER, contact.getNumbers().get(0).getNumber());
        return db.update(Contact.TABLE_NAME, values, Contact.COLUMN_ID + " = ?",
                new String[]{String.valueOf(contact.getId())});
    }

    public void deleteContact(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(Contact.TABLE_NAME, Contact.COLUMN_ID + " = ?",
                new String[]{String.valueOf(contact.getId())});
        db.close();
    }

    public Uri getPhotoUri() {
        try {
            Cursor cur = this.ctx.getContentResolver().query(
                    ContactsContract.Data.CONTENT_URI,
                    null,
                    ContactsContract.Data.CONTACT_ID + "=" + id + " AND "
                            + ContactsContract.Data.MIMETYPE + "='"
                            + ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE + "'", null,
                    null);
            if (cur != null) {
                if (!cur.moveToFirst()) {
                    return null; // no photo
                }
            } else {
                return null; // error in cursor process
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        Uri person = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, Long
                .parseLong(id));
        return Uri.withAppendedPath(person, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY);
    }
}
